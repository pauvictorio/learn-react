# Poll Survey with React Route

This is a simple survey app made with React Route. It allows the user to cast their votes over a set of polls. Once the survey is submitted, the user will be redirected to another route to see the total number of votes for each poll.
